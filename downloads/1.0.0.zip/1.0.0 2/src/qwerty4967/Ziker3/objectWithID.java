package qwerty4967.Ziker3;

public abstract class objectWithID 
{
	//impressive.
	int ID = -1;
}