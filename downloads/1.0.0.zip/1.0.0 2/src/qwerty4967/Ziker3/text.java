package qwerty4967.Ziker3;

public class text extends variable 
{
	// this is a string or something
	
	
	
	
	// Constructors. woo.
	text( String name, String  value)
	{
		super( name );
		this.value=value;
		this.type ="string";
	}
	
	public void setValue( String value)
	{
		 this.value=value;
	}
	public void setValue( int value)
	{}
	public void setValue( boolean value)
	{}
}

